# Bitácora · Día 2 · Herramientas de desarrollo

- **Coder:**
- **Fecha:**
- **TL:**

---

## 1. Mi entorno de desarrollo (Etapa 1)

- Versión de Ubuntu: Ubuntu 26.04.1 LTS
- Versión de Python: Python 3.14.4
- ¿Dónde está instalado Python? (resultado de `which python3`): /usr/bin/python3
- Con mis palabras, la diferencia entre un compilador y un intérprete es: La diferencia entre un compilador y un interprete esta en como traducen el codigo ,ya que, el compilador lo traduce a un lenguaje que el sistema pueda leer haciendo que este sea por lo general mas rapido por ser de tipado fuerte; mientras que el interprete lee linea por linea demorandose un poco mas pero siendo mas flexible en el tipado

- ¿Qué pasó con la línea 4 de `hola.py` y por qué?: Nunca se ejecuto ya que el programa al leer linea por linea y detectar un error antes de siquiera ejecutarla arroja el error que encontro.


| Herramienta | ¿Qué es? (sistema operativo, editor, intérprete, compilador o navegador) |
|---|---|
| Ubuntu | navegador |
| VS Code | editor |
| Python | interprete |
| Chrome | navegador |
| gcc | compilador |

## 2. Reinstalación de VS Code (Etapa 2)

- ¿Cómo estaba instalado VS Code? (snap, .deb o no estaba): Estaba instalado en .deb 
- Comando que usé para desinstalarlo: sudo apt install ./code_*.deb
- Comando que usé para instalarlo: sudo apt install ./code_*.deb
- ¿Por qué es importante instalar desde la fuente oficial?: porque si no se instala desde un sitio oficial podria tener un software malicioso
- ¿Qué pasó con mi configuración al desinstalar? ¿Dónde vive?: mi configuracion de igual manera esta a salvo, ya que, vive en la memoria del dispositivo mas no de la aplicacion

## 3. Perfiles y extensiones (Etapa 3)

- Con mis palabras, un perfil de VS Code es: Un perfil de VScode es una configuracion del entorno de trabajo en donde se gudran determinadas preferencias de la aplicacion para mayor comodidad dependiendo del trabajo o persona 

- ¿Qué cambia en el Explorador entre un perfil y otro?: Cambia las preferencias que se hayan seleccionado tal como el tema o la extension de error lens, sin embargo no cambian los archivos, ya que, como dije anteriormente estos se guardan en el sistema
- ¿Por qué VS Code pregunta si confío en el publicador de una extensión?: Ya que al igual que en las aplicaciones puede contener distintas cosas que no mencioan puntualmente y hacen acciones a espaldas del usuario 

## 4. Duelo de perfiles (Etapa 4)

| Prueba | Perfil2-Basico | Perfil1-Pro |
|---|---|---|
| 1. Auto guardado | No | Si |
| 2. Auto Rename Tag | No | Si |
| 3. Error Lens | No | Si |
| 4. Íconos | No | Si |
| 5. Guías de indentación | No | Si |
| 6. Extensiones corriendo | No | Si |

**Reflexión**

1. ¿Noté diferencias en la experiencia de trabajo entre los dos perfiles? ¿Cuáles?
   - En el Perfil1-pro hay bastantes facilidades que ahorran segundos valiosos para la productividad del programador 
2. ¿Qué ventajas tiene usar múltiples perfiles en VS Code?
   - Cada perfil que se use puede adaptarse mejor a diferentes tareas que se necesite realizar
3. ¿Cómo influyen las extensiones en la productividad y en el rendimiento del editor?
   - Bien dependiendo de las que se tenga y como se aprovechen 
4. ¿Cuándo sería útil usar perfiles distintos en un entorno profesional? (dos ejemplos)
   - seria bueno utilizar dos perfiles cuando se va a programar una pagina y necesitas el backend y el frontend, ya que, hay herramientas que funcionan mejor para la tarea que se requiera 

## 5. Inspección y modificación (Etapa 5)

- Página que usé: https://es.wikipedia.org/wiki/Medell%C3%ADn
- Cinco etiquetas que encontré y para qué sirven: 
  1. <div division de contenido
  2. <a permite verificar si la url esta bien escrita 
  3. <image pérmite insertar imagenes de forma nativa 
  4. <h1 sirve para colocar un titulo mas grande 
  5. <button sirve para colocar un boton en la pagina
- ¿Qué pasó con mis cambios al recargar y por qué?: desaparecieron porque los cambios que hice fue exclusivamente para mi, al reiniciar muestra la pagina original ya que esa url pertenece a lo que vimos en un principio
- Con mis palabras, el DOM es: es 

## 6. La consola (Etapa 6)

| Operación | Mi predicción | Resultado real |
|---|---|---|
| `2 + 3` | 5 | 5 |
| `10 - 4 * 2` | 2 | 2 |
| `(10 - 4) * 2` | 12 | 12 |
| `10 / 4` | 2.5 | 2.5 |
| `10 % 3` | 0.99 | 1 |
| `2 ** 8` | 256 | 256 |
| `120000 * 0.19` |22800 | 22800|
| `365 * 24` |8760 |  8760|

- ¿Por qué `0.1 + 0.2` no da exactamente `0.3`?:
- Errores o advertencias que encontré en la página (o "ninguno"): ninguno
- Diferencia entre un error y una advertencia: el error es algo que no se puede hacer o no compila en cambio la advertencia es algo que puede pasar 

## 7. La red / Network (Etapa 7)

| Imagen | Formato | Tamaño | Tiempo | Código de estado |
|---|---|---|---|---|
| image.php|svg | 774 B| 187 MS| 200 OK|
| generate_204| svg|0 B | 76 ms| 204 OK|
| Imagen1%20%281%29| png| 3.77 kb| 0 ms| 200 OK|

| Experimento | Solicitudes | Transferido | Load |
|---|---|---|---|
| A. Sin caché | | | |
| B. Con caché | | | |
| C. Red lenta | | | |

- Archivo más pesado de la página y su tipo: se llama first.js y es de tipo .js 
- ¿Por qué la página cargó más rápido con caché?: porque tenia donde almacenar datos ambulatoriamente 
- ¿Por qué un desarrollador querría probar con una red lenta?: para ver que cada usuario pueda tener una buena experiencia con su pagina 
- ¿Qué haría para que una imagen pesada cargue más rápido?: comprimirla restandole calidad o activando el cache y teniendo una buena conexion a internet 

## 8. Dispositivos móviles (Etapa 8)

| Ancho (px) | Dispositivo | ¿Cambia el menú? | ¿Imágenes bien? | ¿Scroll horizontal? | Observación |
|---|---|---|---|---|---|
| 320 |iphone xr | se vuelve menos ancho|se alcanza a ver una parte de la imagen |no| es poco comodo|
| 375 |iphone xr | es solo un poco mas ancho| falta ver contenido| no| es poco comodo|
| 768 |iphone xr | es mucho mas ancho| se alnza a ver en su totalidad las imagenes| no|ya es bastante practico y comodo |
| 1024 | iphone xr| se ve bastante ancho| un poco distorsionadas|no | se pierde un poco de proporcionalidad en las imagenes|
| 1440 |iphone xr  | es mucho mas ancho de lo visualmente comodo| no mucho| no| |

- ¿Por qué es importante probar varias resoluciones antes de entregar un proyecto?:

## 9. Laboratorio de errores (Etapa 9)

| # | Tipo | ¿Dónde lo detecté? | Mensaje o síntoma | Causa | Solución aplicada |
|---|---|---|---|---|---|
| 1 | 404 |en el developer tools | file not found|no habia una imagen en la parte que el codigo pretendia encontrarla | poner una imagen |
| 2 |404 | en la consola| file not found| no encontraba el estilo de css|colocar bien la ruta |
| 3 | sintaxis| en el codigo| no pasa nada cuando aprieto el boton de saludar| copiar mal el nombre de las variable| corregir el nombre de alguna de las dos variables|
| 4 | sintaxis| codigo| no dejaba colocar el nombre del coder en el mensaje|mal sintaxis |copiar bien la variable |

- Uno de los errores, descrito con detalle, y cómo lo resolví:una de las imagenes que se encontraba en la carpeta de images no llevaba a nada entonces reemplace la imagen con una que si funcionaba en la misma carpeta, el erro que tiraba en la consola es el 404 de file not found
- ¿Qué vi al pausar con el breakpoint?: debbuger paused
- ¿Qué pasó al cambiar `visitas` por 99 y al borrarlo?:al ponerle 99 solo siguio contando las visitas y al borrarlo por mas que recargaba no las contaba
- ¿Para qué usan el localStorage las páginas reales? ¿Qué NO debería guardar ahí?: usan el localstorage para guardar datos sensibles es decir de los usuarios ahi no deberian guardar datos que correspondan a la pagina
- Ancho exacto en el que se apilan las tarjetas y regla de CSS responsable:cambia el ancho de los elementos de la pagina
- ¿Por qué no basta con mirar solo la consola para encontrar errores?:porque pueden haber errores silenciosos que no se muestren exactamente ahi

## 10. Comparación con Firefox (Etapa 10)

| Herramienta | Chrome: nombre y atajo | Firefox: nombre y atajo | Diferencia que noté |
|---|---|---|---|
| Inspeccionar HTML y CSS | Elements (Ctrl + Shift + C) | Inspector (Ctrl + Shift + C) | Ambos permiten inspeccionar y modificar HTML y CSS en tiempo real. |
| Consola | Console (Ctrl + Shift + J) | Consola web (Ctrl + Shift + K) | Ambas permiten ejecutar JavaScript y ver errores, pero la interfaz y algunas opciones son diferentes. |
| Red | Network (Ctrl + Shift + J y seleccionar Network) | Red (Ctrl + Shift + E) | Ambas muestran las solicitudes de red, los tiempos de carga y las respuestas del servidor. |
| Simulación de dispositivos | Device Toolbar (Ctrl + Shift + M) | Modo de diseño adaptable (Ctrl + Shift + M) | Ambas permiten simular dispositivos móviles y cambiar el tamaño de la pantalla. |
| Almacenamiento local | Application > Local Storage | Almacenamiento > Almacenamiento local | Ambas permiten consultar, modificar y eliminar datos guardados en el almacenamiento local. |
| Mensaje del error que reintroduje | Console | Consola web | En ambas herramientas se muestran los errores de JavaScript en rojo y se puede consultar el archivo y la línea donde ocurren. |

- Una característica de Firefox interesante o diferente a Chrome (qué es, para qué sirve y cómo la probé): el inspector de accesibilidad porque permite visualizar cómo los lectores de pantalla interpretan una página web y detectar problemas de accesibilidad, como botones sin etiquetas o textos con poco contraste.

## 11. Reflexión final (Etapa 11)

- La herramienta que más voy a usar y por qué: la herramienta que mas voy a utiliar seria la consola para ver que errores puedo resolver con mas facilidad llendo a la linea que me indican desde el devtools
- Lo más difícil del día y cómo lo resolví: lo mas dificil de resolver fue los errores silenciosos porque no los notaba con facilidad
- Las DevTools explicadas para alguien que no programa (3 líneas): las devtools funcionan para la gente que quiere ver el funcionamiento y estructura de una pagina cualquiera o creada por si mismo, en donde no solo estara reflejado sus elemntos visuales si no tambien los funcionales 